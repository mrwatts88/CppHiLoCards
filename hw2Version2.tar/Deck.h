//
// Created by matt on 2/6/18.
//

#ifndef DECK_H
#define DECK_H

void initDeck(int[], int);
void shuffle(int[], int);
int dealCard(int[], int&);
void swap(int*, int*);

#endif //CS337HW2_DECK_H
